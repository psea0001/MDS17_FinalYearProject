package com.example.fyp_app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONObject;

import okhttp3.*;
import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private static int CAMERA_PERM_CODE = 100;
    private static int VID_REC_CODE = 101;

    private Uri vidPath;

    private static final String FLASK_SERVER_URL = "http://192.168.1.5:5000/upload";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.progress), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button getStartedButton = findViewById(R.id.back_button);
        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to MainActivity
                Intent intent = new Intent(MainActivity.this, WelcomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        if (isCameraPresent()) {
            Log.i("VIDEO_RECORDER_TAG", "Camera detected");
            getCamPermission();
        }
        else {
            Log.i("VIDEO_RECORDER_TAG", "No camera detected");
        }
    }

    public void recordVideoButtonPressed(View view) {

        recordVideo();

    }

    private boolean isCameraPresent() {
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            return true;
        }
        else {
            return false;
        }
    }

    private void  getCamPermission () {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED)
        {

            ActivityCompat.requestPermissions(this, new String[]
                    {Manifest.permission.CAMERA},CAMERA_PERM_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERM_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Log.i("VIDEO_RECORDER_TAG", "Camera permission granted");
            } else {
                // Permission denied
                Log.i("VIDEO_RECORDER_TAG", "Camera permission denied");
            }
        }
    }

    private void recordVideo() {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, VID_REC_CODE);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == VID_REC_CODE) {

            if (resultCode == RESULT_OK) {

                vidPath = data.getData();
                Log.i("VIDEO_RECORDER_TAG", "Videos recorded is at path: " + vidPath);

                // go to the processing screen
                navigateToProgScreen();

                // Convert the URI to a file path
                String videoFilePath = getRealPathFromURI(vidPath);
                Log.i("VIDEO_RECORDER_TAG", "Video file path: " + videoFilePath);
                // Upload the video file to Flask server
                uploadVideoToServer(videoFilePath);

            }
            else if (resultCode == RESULT_CANCELED) {
                Log.i("VIDEO_RECORDER_TAG", "Recorded video canceled");
            }
        }
    }

    // Helper function to get the real file path from a URI
    private String getRealPathFromURI(Uri contentUri) {
        String[] proj = { MediaStore.Video.Media.DATA };
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor != null) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
            cursor.moveToFirst();
            return cursor.getString(column_index);
        }
        return null;
    }

    // After video recording, call this to upload the video to Flask server
    private void uploadVideoToServer(String videoPath) {
        OkHttpClient client = new OkHttpClient();

        // Get the video file
        File videoFile = new File(videoPath);

        // Create a request body with the file
        RequestBody requestBody = new MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("video", videoFile.getName(),
                        RequestBody.create(MediaType.parse("video/mp4"), videoFile))
                .build();

        // Create a POST request to upload the video
        Request request = new Request.Builder()
                .url(FLASK_SERVER_URL)
                .post(requestBody)
                .build();

        // Execute the request asynchronously
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                // Handle the error (show message to user, etc.)
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    // Get the JSON response from the server
                    String jsonResponse = response.body().string();
                    Log.i("FLASK_SERVER", "Server Response: " + jsonResponse);

                    // Parse the JSON response to extract the heart rate values
                    try {
                        JSONObject jsonObject = new JSONObject(jsonResponse);
                        double heartRateCombined = jsonObject.getDouble("heart_rate_combined");

                        // Navigate to HeartRateActivity and pass the heart rate values
                        Intent intent = new Intent(MainActivity.this, HeartRateActivity.class);
                        intent.putExtra("heart_rate_combined", heartRateCombined);
                        startActivity(intent);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Log.e("FLASK_SERVER", "Upload failed with response code: " + response.code());
                }
            }
        });
    }

    private void navigateToProgScreen() {
        Intent intent = new Intent(MainActivity.this, ProgressActivity.class);
        intent.putExtra("VIDEO_PATH", vidPath.toString());
        startActivity(intent);
    }
}