import cv2
import numpy as np
import time


class VideoProcessor:
    def __init__(self):
        """Initializes the VideoProcessor with default settings."""
        self.video_path = ""
        self.cap = None
        self.start_time = 0
        self.frames_to_process = 0

    def set_video_path(self, path):
        """Sets the path of the video file to be processed.

        Args:
            path (str): Path to the video file.
        """
        self.video_path = path

    def start(self):
        """Starts video capture from the specified video file."""
        if not self.video_path:
            print("Invalid filename!")
            return

        self.cap = cv2.VideoCapture(self.video_path)
        if not self.cap.isOpened():
            print("Failed to open the video file.")
            return

        fps = self.cap.get(cv2.CAP_PROP_FPS)
        print("Frames per second:", fps)

        self.frames_to_process = int(fps * 10)  # Process only first 10 seconds
        print("Total frames to process:", self.frames_to_process)

        self.start_time = time.time()
        print("Start time:", self.start_time)

        # Try to get the first frame to check if the video capture is valid
        self.valid = self.cap.read()[0]
        if not self.valid:
            print("Failed to read the first frame.")

    def stop(self):
        """Stops the video capture and releases the resources."""
        if self.cap:
            self.cap.release()
            self.cap = None
            print("Video stopped.")

    def get_frame(self):
        """Retrieves and processes a single frame from the video.

        Returns:
            numpy.ndarray: The processed frame or an error frame if the video cannot be processed.
        """
        if self.valid:
            ret, frame = self.cap.read()
            if not ret:
                print("End of video.")
                self.stop()
                print("Total video time:", time.time() - self.start_time)
                return None
            return cv2.resize(frame, (640, 480))
        else:
            # Return an error frame
            # for numpy, 1st dimension is height
            # 2nd dimension is weight
            # 3rd is for the RGB value
            error_frame = np.ones((480, 640, 3), dtype=np.uint8) * 255 # return empty frame
            #cv2.putText(error_frame, "(Error: Can not load the video)",
                        #(50, 240), cv2.FONT_HERSHEY_PLAIN, 2, (0, 0, 255), 2)
            return error_frame


