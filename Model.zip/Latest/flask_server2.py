from flask import Flask, request, jsonify
import os
from main2 import process_video_file  # Import the refactored function

app = Flask(__name__)

# Directory to store uploaded videos
UPLOAD_FOLDER = 'uploaded_videos'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        return jsonify({"error": "No video file provided"}), 400

    video_file = request.files['video']
    
    if video_file.filename == '':
        return jsonify({"error": "No selected file"}), 400

    # Save the uploaded video file
    video_path = os.path.join(UPLOAD_FOLDER, video_file.filename)
    video_file.save(video_path)

    # Call the refactored function from main.py to process the video
    heart_rate_combined = process_video_file(video_path)

    # Return the result to the Android app
    return jsonify({
        "heart_rate_combined": heart_rate_combined
    }), 200

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)