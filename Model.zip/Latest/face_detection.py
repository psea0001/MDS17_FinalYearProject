import cv2
import mediapipe as mp
import numpy as np

class FaceDetection:
    def __init__(self):
        self.mp_face_detection = mp.solutions.face_detection
        self.mp_face_mesh = mp.solutions.face_mesh
        self.face_detection = self.mp_face_detection.FaceDetection(min_detection_confidence=0.3)
        self.face_mesh = self.mp_face_mesh.FaceMesh(static_image_mode=False, max_num_faces=1, refine_landmarks=True, min_detection_confidence=0.3)

    def face_detect(self, frame):
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.face_detection.process(frame_rgb)
        face_frame = frame.copy()
        status = False
        cropped_frame = None

        if results.detections:
            status = True
            for detection in results.detections:
                bboxC = detection.location_data.relative_bounding_box
                ih, iw, _ = frame.shape
                x, y, w, h = int(bboxC.xmin * iw), int(bboxC.ymin * ih), int(bboxC.width * iw), int(bboxC.height * ih)
                cropped_frame = frame[y:y + h, x:x + w]
                break  # Assuming only one face per frame for simplicity

        return face_frame, cropped_frame, status

    def extract_eyes_areas_by_mesh(self, cropped_frame):
        combined_box = None, None
        if cropped_frame is not None and cropped_frame.size > 0:
            mesh_results = self.face_mesh.process(cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2RGB))
            if mesh_results.multi_face_landmarks:
                for landmarks in mesh_results.multi_face_landmarks:
                    cropped_frame, combined_box = self.draw_eyes_boxes(cropped_frame, landmarks)
                    return cropped_frame, combined_box
        else:
            print("Cropped frame is empty or None")

        return cropped_frame, combined_box

    def draw_eyes_boxes(self, frame, landmarks):
        h, w, _ = frame.shape
        # Define cheek landmarks indices based on actual MediaPipe results

        left_eyes_indices = [234, 93, 132, 129]
        right_eyes_indices = [454, 323, 362, 359]

        left_x = int(min([landmarks.landmark[i].x for i in left_eyes_indices]) * w)
        left_y = int(min([landmarks.landmark[i].y for i in left_eyes_indices]) * h)
        left_w = int(max([landmarks.landmark[i].x for i in left_eyes_indices]) * w) - left_x
        left_h = int(max([landmarks.landmark[i].y for i in left_eyes_indices]) * h) - left_y

        right_x = int(min([landmarks.landmark[i].x for i in right_eyes_indices]) * w)
        right_y = int(min([landmarks.landmark[i].y for i in right_eyes_indices]) * h)
        right_w = int(max([landmarks.landmark[i].x for i in right_eyes_indices]) * w) - right_x
        right_h = int(max([landmarks.landmark[i].y for i in right_eyes_indices]) * h) - right_y

        new_left_x, left_w = self.adjust_box_position_and_size(left_x, left_y, left_w, left_h, w)
        right_x, right_w = self.adjust_box_position_and_size(right_x, right_y, right_w, right_h, w)

        new_right_y = right_y + 18
        new_right_x = right_x + 15

        # Adjust the bounding box to exclude non-skin regions
        new_left_x, left_y, left_w, left_h = self.adjust_roi(new_left_x, left_y, left_w, left_h, frame)
        new_right_x, new_right_y, right_w, right_h = self.adjust_roi(new_right_x, new_right_y, right_w, right_h, frame)

        # Determine the combined box coordinates
        combined_x = 0
        combined_y = new_right_y  # Start from the higher (on the screen) of the two boxes
        combined_w = w  # Width from left edge of left box to right edge of right box
        #combined_h = left_h 
        combined_h = max(left_y + left_h, right_y + right_h) - combined_y

        combined_w = min(combined_w, w - combined_x)

        combined_x, combined_y, combined_w, combined_h = self.adjust_roi(combined_x, combined_y, combined_w, combined_h, frame)

        combined_cheek_box = (combined_x, combined_y, combined_w, combined_h)

        return frame, combined_cheek_box


    def adjust_roi(self, x, y, w, h, frame):
        if w <= 0 or h <= 0 or x < 0 or y < 0 or x + w > frame.shape[1] or y + h > frame.shape[0]:
            return x, y, w, h  # Return original if invalid ROI

        frame_hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        lower_hsv = np.array([0, 30, 60])
        upper_hsv = np.array([20, 150, 255])
        mask = cv2.inRange(frame_hsv[y:y + h, x:x + w], lower_hsv, upper_hsv)

        skin_percentage = np.count_nonzero(mask) / (w * h)
        threshold = 1
        if skin_percentage < threshold:
            x += int(w * 0.05)
            #y += int(h * 0.01)
            w = int(w * 0.95)
            h = int(h * 0.95)

        return x, y, w, h

    def adjust_box_position_and_size(self, x, y, w, h, frame_width):
        # Adjust x coordinate to start at zero if it's less than zero
        if x < 0:
            x = 0

        # Check if the box extends beyond the frame width
        if x + w > frame_width:
            # Adjust the width only if it exceeds the frame boundaries
            w = frame_width - x

        return x, w