import numpy as np
import cv2

class MeanValueCalculator:
    @staticmethod
    def calculate_mean_values(cropped_frame):
        # Ensure the frame is in the 8-bit format
        cropped_frame = (cropped_frame * 255).astype(np.uint8)

        # Calculate the mean values of RGB channels
        mean_r = np.mean(cropped_frame[:, :, 2])
        mean_g = np.mean(cropped_frame[:, :, 1])
        mean_b = np.mean(cropped_frame[:, :, 0])

        # Calculate the mean values of YCrCb channels
        ycrcb = cv2.cvtColor(cropped_frame, cv2.COLOR_BGR2YCrCb)
        mean_y = np.mean(ycrcb[:, :, 0])
        mean_cr = np.mean(ycrcb[:, :, 1])
        mean_cb = np.mean(ycrcb[:, :, 2])
        return mean_r, mean_g, mean_b
        # return mean_r, mean_g, mean_b, mean_y, mean_cr, mean_cb

    @staticmethod
    def normalize_frame(frame):
        # Convert the frame to float32 for precision in calculations
        frame = frame.astype(np.float32)

        # Calculate mean and standard deviation for each channel
        mean, std = cv2.meanStdDev(frame)

        # Reshape mean and std to match the frame dimensions
        mean = mean.reshape((1, 1, 3))
        std = std.reshape((1, 1, 3))

        # Normalize the frame
        normalized_frame = (frame - mean) / (std + 1e-8)  # Adding a small value to avoid division by zero

        return normalized_frame
