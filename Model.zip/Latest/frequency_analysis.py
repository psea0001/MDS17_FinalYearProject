import numpy as np
import matplotlib.pyplot as plt
import matplotlib

matplotlib.use('TkAgg')

from scipy.signal import butter, lfilter

class FrequencyAnalysis:
    @staticmethod
    def perform_fft(signal):
        freq = np.fft.fft(signal)
        freq_magnitude = np.abs(freq)
        return freq, freq_magnitude

    @staticmethod
    def plot_frequency_components(freq1_magnitude):
        freq_domain = np.fft.fftfreq(len(freq1_magnitude))

        plt.figure(figsize=(12, 6))
        plt.subplot(2, 1, 1)
        plt.plot(freq_domain, freq1_magnitude)
        plt.title('PCA1 Frequency Components')
        plt.xlabel('Frequency')
        plt.ylabel('Magnitude')

        plt.tight_layout()
        plt.show()

    @staticmethod
    def butter_bandpass(lowcut, highcut, fs, order=4):
        nyquist = 0.5 * fs
        low = lowcut / nyquist
        high = highcut / nyquist
        b, a = butter(order, [low, high], btype='band')
        return b, a

    @staticmethod
    def bandpass_filter(data, lowcut=0.7, highcut=3.0, fs=60.0, order=4):
        b, a = FrequencyAnalysis.butter_bandpass(lowcut, highcut, fs, order=order)
        y = lfilter(b, a, data)
        return y

    @staticmethod
    def get_heart_rate(signal, fs=60.0):
        # Perform FFT
        freq, freq_magnitude = FrequencyAnalysis.perform_fft(signal)

        # Bandpass filter the signal between 0.7 Hz and 4 Hz
        filtered_signal = FrequencyAnalysis.bandpass_filter(signal, lowcut=0.7, highcut=3, fs=fs)

        # Perform FFT on filtered signal
        filtered_freq, filtered_freq_magnitude = FrequencyAnalysis.perform_fft(filtered_signal)

        # Find the peak frequency in the filtered signal
        freq_domain = np.fft.fftfreq(len(filtered_freq_magnitude), d=1/fs)
        peak_freq_index = np.argmax(filtered_freq_magnitude)
        peak_freq = abs(freq_domain[peak_freq_index])

        # Convert peak frequency to heart rate (beats per minute)
        heart_rate = peak_freq * 60.0
        print("PREAK = ", peak_freq)
        return heart_rate, filtered_signal, filtered_freq_magnitude
    
    def estimate_heart_rate(signal, fs=60):
        N = len(signal)
        freqs = np.fft.fftfreq(N, 1/fs)
        fft_values = np.abs(np.fft.fft(signal))

        # Focus only on positive frequencies in the heart rate range
        valid_freqs = (freqs > 0.7) & (freqs < 3.0)
        heart_rate_freq = freqs[valid_freqs][np.argmax(fft_values[valid_freqs])]
        print("heart rate frequency", heart_rate_freq)
        # Convert frequency to BPM
        heart_rate_bpm = heart_rate_freq * 60
        return heart_rate_bpm, fft_values, freqs
    
    @staticmethod
    def plot_filtered_frequency_components(filtered_freq_magnitude, fs=30.0):
        freq_domain = np.fft.fftfreq(len(filtered_freq_magnitude), d=1/fs)

        plt.figure(figsize=(12, 6))
        plt.plot(freq_domain, filtered_freq_magnitude)
        plt.title('Filtered Frequency Components')
        plt.xlabel('Frequency (Hz)')
        plt.ylabel('Magnitude')
        plt.xlim(0, 5)  # Focus on the range of interest
        plt.grid()
        plt.show()
