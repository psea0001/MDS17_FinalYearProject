import numpy as np
from scipy.signal import welch
import ica

import numpy as np
from scipy.signal import welch

def calculate_psd(signal, fs=30.0):
    """Calculate the Power Spectral Density (PSD) of a signal."""
    nperseg = min(256, len(signal))
    freqs, psd = welch(signal, fs=fs, nperseg=nperseg)
    return freqs, psd

def calculate_snr(signal, noise_band=(0.0, 0.6), fs=30.0):
    """Calculate the Signal-to-Noise Ratio (SNR) of a signal."""
    freqs, psd = calculate_psd(signal, fs)

    # Estimate power in the noise band (e.g., frequencies below heart rate range)
    noise_power = np.sum(psd[(freqs >= noise_band[0]) & (freqs <= noise_band[1])])

    # Estimate signal power in the heart rate frequency range (e.g., 0.7 to 3.0 Hz)
    signal_power = np.sum(psd[(freqs >= 0.8) & (freqs <= 3.0)])

    # Calculate the SNR (signal-to-noise ratio)
    snr = signal_power / (noise_power + 1e-6)  # Add small value to avoid division by zero
    return snr

def evaluate_signal_quality(components, fs=30.0, freq_range=(0.8, 3.0)):
    """Evaluate the quality of the signal based on PSD in the heart rate frequency range."""
    best_component = None
    best_psd_value = -np.inf

    # Iterate over each component and calculate its PSD
    for i, component in enumerate(components.T):  # Transpose to iterate over components
        freqs, psd = calculate_psd(component, fs)

        # Sum the power in the heart rate frequency range
        power_in_band = np.sum(psd[(freqs >= freq_range[0]) & (freqs <= freq_range[1])])

        if power_in_band > best_psd_value:
            best_psd_value = power_in_band
            best_component = component

    return best_component, best_psd_value

def auto_adjust_ica_components(data, fs=30.0, ica_instance=None):
    """Automatically adjust the number of ICA components based on SNR."""
    best_snr_value = -np.inf
    best_n_components = 0
    best_component = None

    # Specify the component choices you want to test (e.g., 1, 3, and 5)
    component_choices = [1,3,5]

    n_features = data.shape[1]

    # Loop over only 1, 3, and 5 components
    for n_components in component_choices:  
        if n_components > n_features:
            continue

        # Use the custom apply_ica method from your ICA class
        components = ica.apply_ica(data, n_components)

        # Iterate over each component and calculate its SNR
        for i, component in enumerate(components.T):
            snr_value = calculate_snr(component, fs=fs)

            # Keep track of the component with the highest SNR
            if snr_value > best_snr_value:
                best_snr_value = snr_value
                best_n_components = n_components
                best_component = component

    return best_component, best_n_components