import matplotlib.pyplot as plt
import matplotlib
import numpy
def plot_rgb(rgb_mean: list):
    
    r_values = [rgb[0] for rgb in rgb_mean]  # Extract R values
    g_values = [rgb[1] for rgb in rgb_mean]  # Extract G values
    b_values = [rgb[2] for rgb in rgb_mean]  # Extract B values
    plt.figure(figsize=(12, 6))
    time = range(len(rgb_mean))
    plt.plot(time, r_values, label='Red', color='r')  # Plot Red values
    plt.plot(time, g_values, label='Green', color='g')  # Plot Green values
    plt.plot(time, b_values, label='Blue', color='b')  # Plot Blue values
    plt.title('RGB')
    plt.xlabel('Time(frames)')
    plt.ylabel('Mean')
    plt.grid()
    plt.show()

def plot_ica_signal(component: list):
    plt.figure(figsize=(12, 6))
    item = [rgb[1] for rgb in component]  # Extract R values
    time = range(len(component))
    plt.plot(time, item, label='signal', color='black') 
    max_value = max(item)
    max_y     = item.index(max_value)
    plt.annotate(f'Maximum value: {max_value}' ,xy=(max_y, max_value), xytext=(max_y, max_value + 5))

    # plt.plot(time, component[:, 2], label='signal', color='green') 
    plt.title("ICA signal")
    plt.grid()
    plt.show()

def plot_bandpass_signal(signal: list):
    plt.figure(figsize=(12, 6))
    time = range(len(signal))
    plt.plot(time, signal, label='signal', color='black') 

    # plt.plot(time, component[:, 2], label='signal', color='green') 
    plt.title("Bandpass signal")
    plt.grid()
    plt.show()