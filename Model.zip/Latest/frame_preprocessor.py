from mean_value_calculator import MeanValueCalculator
import cv2
import numpy as np

class FramePreprocessor:
    def __init__(self):
        pass

    @staticmethod
    def preprocess_frame(frame):
        # Convert frame to 8-bit if it is not already
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0, 0, 255).astype(np.uint8)

        # Apply color magnification and other preprocessing steps
        #frame = FramePreprocessor.apply_color_magnification(frame)
        #frame = MeanValueCalculator.normalize_frame(frame)
        #return frame

        # Dynamically adjust parameters based on image characteristics
        contrast_enhanced = FramePreprocessor.dynamic_contrast_adjustment(frame)
        blurred = FramePreprocessor.adaptive_blurring(contrast_enhanced)

        return blurred

    @staticmethod
    def preprocess_frame_original(frame):
        # Convert frame to 8-bit if it is not already
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0, 0, 255).astype(np.uint8)

        # Apply color magnification and other preprocessing steps
        frame = FramePreprocessor.apply_color_magnification(frame)
        #frame = MeanValueCalculator.normalize_frame(frame)
        return frame
    
    @staticmethod
    def preprocess_frame_3(frame):
        # Convert frame to 8-bit if it is not already
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0, 0, 255).astype(np.uint8)

        # Apply color magnification and other preprocessing steps
        frame = FramePreprocessor.apply_homomorphic_filter(frame)

        return frame
    
    @staticmethod
    def preprocess_frame_4(frame):
        # Convert frame to 8-bit if it is not already
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0, 0, 255).astype(np.uint8)

        # Apply color magnification and other preprocessing steps
        frame = FramePreprocessor.median_blur(frame)

        return frame
    
    def median_blur(frame, kernel_size=25):
        blurred = cv2.medianBlur(frame, kernel_size)
        return blurred
    
    @staticmethod
    def apply_homomorphic_filter(frame):
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY).astype(float) / 255
        img_log = np.log(img + 1)
        img_fft = np.fft.fft2(img_log)
        # Create a Gaussian highpass filter
        rows, cols = img.shape
        crow, ccol = rows // 2, cols // 2
        mask = np.ones((rows, cols), dtype=np.float32)
        r = 32  # Radius of the low-frequency suppression
        center = [crow, ccol]
        x, y = np.ogrid[:rows, :cols]
        mask_area = (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
        mask[mask_area] = 0
        fshift = img_fft * mask
        f_ishift = np.fft.ifftshift(fshift)
        img_back = np.fft.ifft2(f_ishift)
        img_back = np.exp(np.real(img_back)) - 1
        img_histnorm = cv2.normalize(img_back, None, 0, 255, cv2.NORM_MINMAX)
        final_img = cv2.cvtColor(img_histnorm.astype(np.uint8), cv2.COLOR_GRAY2BGR)
        return final_img

    # improve the contrast of the image frame
    @staticmethod
    def dynamic_contrast_adjustment(frame):
        try:
            ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)
            channels = list(cv2.split(ycrcb))  # Convert tuple to list

            # improves the local contrast of an image by equalizing the histogram of the brightness
            clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(14 , 16))
            channels[0] = clahe.apply(channels[0])

            merged = cv2.merge(channels)
            return cv2.cvtColor(merged, cv2.COLOR_YCrCb2BGR)
        except Exception as e:
            print(f"Error in dynamic_contrast_adjustment: {e}")
            return None

    # adaptive blurring based on the sharpness or noise level of the image
    @staticmethod
    def adaptive_blurring(frame):
        # Calculate the variance of the image
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        variance = cv2.Laplacian(gray, cv2.CV_64F).var()

        # Apply more blurring if the variance is too low (meaning image is likely very noisy)
        if variance < 50:
            kernel_size = (5, 5)
        else:
            kernel_size = (3, 3)

        blurred = cv2.GaussianBlur(frame, kernel_size, 0)
        return blurred

    # enhances colors and reduces noise in an image
    @staticmethod
    def apply_color_magnification(frame):
        # First check and ensure the frame is in the correct format
        if frame.dtype != np.uint8:
            frame = np.clip(frame * 255.0, 0, 255).astype(np.uint8)
            print("Corrected frame data type for color magnification.")

        # Convert to YCrCb color space less sensitive to lighting variations
        ycrcb = cv2.cvtColor(frame, cv2.COLOR_BGR2YCrCb)

        # Histogram equalization on the Y channel to improve contrast
        ycrcb[:, :, 0] = cv2.equalizeHist(ycrcb[:, :, 0])

        # Gaussian blur to reduce high-frequency noise
        blurred = cv2.GaussianBlur(ycrcb, (5, 5), 0)

        # Convert back to BGR for further processing
        processed_frame = cv2.cvtColor(blurred, cv2.COLOR_YCrCb2BGR)

        return processed_frame
    
