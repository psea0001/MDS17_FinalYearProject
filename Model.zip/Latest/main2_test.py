from video_processing import VideoProcessor
from face_detection import FaceDetection
from frame_preprocessor import FramePreprocessor
from mean_value_calculator import MeanValueCalculator
from frequency_analysis import FrequencyAnalysis
import ica
import psd
import os
import cv2
import glob
import numpy as np
import plot_graph
from sklearn.decomposition import PCA, FastICA
# Assuming these functions are already defined based on your code
from pyramid_functions import build_laplacian_pyramid, collapse_laplacian_video_pyramid
from sklearn.preprocessing import StandardScaler

def save_frame(frame, frame_index, output_dir, tag):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    filename = f"frame_{frame_index:04d}{tag}.png"
    filepath = os.path.join(output_dir, filename)
    cv2.imwrite(filepath, frame)

def save_cropped_box(frame, frame_index, output_dir, tag=""):
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    if frame.size > 0:
        filename = f"frame_{frame_index:04d}{tag}.png"
        filepath = os.path.join(output_dir, filename)
        cv2.imwrite(filepath, frame)
    else:
        print(f"Frame {frame_index}: Cropped box is empty or invalid")

def cleanup_files(directory, pattern="*.png"):
    path_pattern = os.path.join(directory, pattern)
    files = glob.glob(path_pattern)
    for file in files:
        try:
            os.remove(file)
        except OSError as e:
            print(f"Error: {file} : {e.strerror}")


if __name__ == '__main__':
    video_path = "D:\\FYP2\\algorithm-testing\\Latest\\Data\\B2.mp4"
    facial_img_path = "D:/fyp_testing/image"
    cheeks_img_path = "D:/fyp_testing/cheeks"

    cleanup_files(facial_img_path, "*")
    cleanup_files(cheeks_img_path, "*")
    print("Cleanup completed.")

    video_processor = VideoProcessor()
    face_detector = FaceDetection()
    
    video_processor.set_video_path(video_path)
    video_processor.start()

    frame_index = 0
    mean_values_list = []
    mean_values_list1 = []
    mean_values_list2 = []

    while True and (frame_index < video_processor.frames_to_process):
        frame = video_processor.get_frame()
        if frame is None:
            break

        processed_frame, cropped_frame, status = face_detector.face_detect(frame)
        if status:  # If a face was detected
            if cropped_frame is not None:
                processed_face, combined_box = face_detector.extract_eyes_areas_by_mesh(cropped_frame)
                if processed_face is not None:
                    save_frame(processed_face, frame_index, facial_img_path, tag="_processed")
                    if combined_box is not None:
                        if combined_box[0] is None or len(combined_box) < 4:
                            print("Error: Combined box data is incomplete or invalid.")
                        else:
                            combined_cheek_frame = cropped_frame[combined_box[1]:combined_box[1] + combined_box[3],
                                                                 combined_box[0]:combined_box[0] + combined_box[2]]
                            ###
                            if combined_cheek_frame.size == 0:
                                print("Combined cheek frame is empty.")
                                continue

                             # Get the width of the combined frame
                            combined_frame_height, combined_frame_width, _ = combined_cheek_frame.shape

                            # Define the split points to remove the middle part (nose)
                            middle_start = int(combined_frame_width * 0.2)  # Adjust these values based on the specific position of the nose
                            middle_end = int(combined_frame_width * 0.8)

                            # Split the image into left, middle, and right parts
                            left_part = combined_cheek_frame[:, :middle_start]
                            right_part = combined_cheek_frame[:, middle_end:]

                            # Concatenate the left and right parts together horizontally, excluding the middle part
                            final_combined_cheeks = np.concatenate((left_part, right_part), axis=1)

                            #### Apply Laplacian Pyramid ####
                            pyramid = build_laplacian_pyramid(final_combined_cheeks, 3)  # Create a 3-level Laplacian pyramid
                            combined_part = collapse_laplacian_video_pyramid([pyramid], 1)[0]  # Collapse back to original size

                            ####
                            preprocessed_cheek_frame = FramePreprocessor.preprocess_frame_original(combined_part)
                            normalized_cheek_frame = MeanValueCalculator.normalize_frame(preprocessed_cheek_frame)
                            mean_values = MeanValueCalculator.calculate_mean_values(normalized_cheek_frame)
                            mean_values_list.append(mean_values)

                            preprocessed_cheek_frame1 = FramePreprocessor.preprocess_frame(combined_part)
                            normalized_cheek_frame1 = MeanValueCalculator.normalize_frame(preprocessed_cheek_frame1)
                            mean_values_1 = MeanValueCalculator.calculate_mean_values(normalized_cheek_frame1)
                            mean_values_list1.append(mean_values_1)

                            preprocessed_cheek_frame2 = FramePreprocessor.preprocess_frame_3(combined_part)
                            normalized_cheek_frame2 = MeanValueCalculator.normalize_frame(preprocessed_cheek_frame2)
                            mean_values_2 = MeanValueCalculator.calculate_mean_values(normalized_cheek_frame2)
                            mean_values_list2.append(mean_values_2)


                            save_cropped_box(combined_part, frame_index, cheeks_img_path, tag="_combined_cheek")

                else:
                    print(f"Frame {frame_index}: Processed cheeks is None")
            else:
                print(f"Frame {frame_index}: Cropped frame is None or empty")
        else:
            print(f"Frame {frame_index}: No face detected in this frame.")

        frame_index += 1

    video_processor.stop()
    print("All frames have been processed and saved.")
    
    # Convert mean values list to numpy arrays
    mean_values_array = np.array(mean_values_list)
    mean_values_array1 = np.array(mean_values_list1)

    # Stack the left and right mean values into a 2D array (frames, 2 signals)
    combined_mean_values = np.column_stack([mean_values_array, mean_values_array1])

    # Perform ICA using sklearn
    components = ica.apply_ica(combined_mean_values)

    if components.shape[1] > 1:
        filtered_signal = FrequencyAnalysis.bandpass_filter(components[:, 1])
    else:
        filtered_signal = FrequencyAnalysis.bandpass_filter(components[:, 0])
    
    # Data post-processing
    heart_rate_combined, filtered_signal_combined, filtered_freq_magnitude_combined = FrequencyAnalysis.estimate_heart_rate(
        filtered_signal)

    # Print out the predicted heart rate
    print(f"Heart Rate (Right Cheek, ICA1): {heart_rate_combined:.2f} BPM")

    # FrequencyAnalysis.plot_filtered_frequency_components(filtered_signal_combined)
    # Plot Graph
    # MEAN RGB
    #plot_graph.plot_rgb(mean_values_list)
    # ICA signal
    #plot_graph.plot_ica_signal(components)
    # Bandpass signal
    #plot_graph.plot_bandpass_signal(filtered_signal)



    