import cv2
import numpy as np

# Build Gaussian image pyramid
def build_gaussian_pyramid(img, levels):
    """
    Builds a Gaussian pyramid from the input image.
    
    :param img: Input image (numpy array).
    :param levels: Number of levels in the pyramid.
    :return: List of images representing the Gaussian pyramid.
    """
    float_img = np.ndarray(shape=img.shape, dtype="float32")
    float_img[:] = img
    pyramid = [float_img]

    for i in range(levels - 1):
        float_img = cv2.pyrDown(float_img)
        pyramid.append(float_img)

    return pyramid


# Build Laplacian image pyramid from Gaussian pyramid
def build_laplacian_pyramid(img, levels):
    """
    Builds a Laplacian pyramid from the input image.
    
    :param img: Input image (numpy array).
    :param levels: Number of levels in the pyramid.
    :return: List of images representing the Laplacian pyramid.
    """
    gaussian_pyramid = build_gaussian_pyramid(img, levels)
    laplacian_pyramid = []

    for i in range(levels - 1):
        upsampled = cv2.pyrUp(gaussian_pyramid[i + 1])
        (height, width, depth) = gaussian_pyramid[i].shape
        upsampled = cv2.resize(upsampled, (width, height))
        laplacian = cv2.subtract(gaussian_pyramid[i], upsampled)
        laplacian_pyramid.append(laplacian)

    laplacian_pyramid.append(gaussian_pyramid[-1])

    return laplacian_pyramid


# Collapse Laplacian pyramid to reconstruct the image
def collapse_laplacian_pyramid(pyramid):
    """
    Collapses a Laplacian pyramid to reconstruct the original image.
    
    :param pyramid: List of Laplacian pyramid layers.
    :return: Reconstructed image from the pyramid.
    """
    prev_frame = pyramid[-1]

    for level in range(len(pyramid) - 2, -1, -1):
        pyr_up_frame = cv2.pyrUp(prev_frame)
        (height, width, depth) = pyramid[level].shape
        pyr_up_frame = cv2.resize(pyr_up_frame, (width, height))
        prev_frame = cv2.add(pyramid[level], pyr_up_frame)

    # Normalize the result to have valid pixel values (0-255)
    prev_frame = np.clip(prev_frame, 0, 255)
    prev_frame = cv2.convertScaleAbs(prev_frame)

    return prev_frame


# Build video pyramid by building Laplacian pyramid for each frame
def build_video_pyramid(frames, levels=3):
    """
    Builds a Laplacian pyramid for each frame in a video.

    :param frames: List of video frames (numpy arrays).
    :param levels: Number of pyramid levels.
    :return: List of Laplacian pyramids for each frame.
    """
    lap_video = []

    for i, frame in enumerate(frames):
        pyramid = build_laplacian_pyramid(frame, levels)
        for j in range(levels):
            if i == 0:
                lap_video.append(np.zeros((len(frames), pyramid[j].shape[0], pyramid[j].shape[1], 3)))
            lap_video[j][i] = pyramid[j]

    return lap_video


# Collapse video pyramid by collapsing each frame's Laplacian pyramid
def collapse_laplacian_video_pyramid(video, frame_ct):
    """
    Collapses the Laplacian pyramid for each frame in the video.

    :param video: List of Laplacian pyramids for each frame.
    :param frame_ct: Number of frames in the video.
    :return: List of reconstructed video frames.
    """
    collapsed_video = []

    for i in range(frame_ct):
        prev_frame = video[-1][i]

        for level in range(len(video) - 1, 0, -1):
            pyr_up_frame = cv2.pyrUp(prev_frame)
            (height, width, depth) = pyr_up_frame.shape
            prev_level_frame = video[level - 1][i]
            prev_level_frame = cv2.resize(prev_level_frame, (width, height))
            prev_frame = cv2.add(pyr_up_frame, prev_level_frame)

        # Normalize pixel values
        prev_frame = np.clip(prev_frame, 0, 255)
        prev_frame = cv2.convertScaleAbs(prev_frame)
        collapsed_video.append(prev_frame)

    return collapsed_video