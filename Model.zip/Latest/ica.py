from sklearn.decomposition import FastICA
import numpy as np

def apply_ica(color_signals):
    # Apply ICA
    ica = FastICA(n_components=3, random_state=1234)
    components = ica.fit_transform(color_signals)
    return components
